my_string = input("Введите любимую цитату: ")
print(len(my_string))
print(my_string.upper())
print(my_string.lower())
print(my_string.replace(' ',''))
print(my_string[0])
print(my_string[-1])

